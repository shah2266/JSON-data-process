<?php
// Database connection string
const DB_HOST = 'localhost';
const DB_NAME = 'booking_system';
const DB_USERNAME = 'common';
const DB_PASSWORD = 'common';

